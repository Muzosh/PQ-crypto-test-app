#ifndef ENCRYPT_H
#define ENCRYPT_H
/*
  This file is for Niederreiter encryption
*/


void encrypt(unsigned char * /*s*/, unsigned char * /*e*/, const unsigned char * /*pk*/);

#endif

